import streamlit as st
import cv2
import numpy as np
from streamlit_webrtc import VideoTransformerBase, webrtc_streamer, WebRtcMode, AudioProcessorBase
import speech_recognition as sr
from transformers import pipeline
import os
import tempfile
import time
import json
import subprocess
from moviepy.editor import VideoFileClip
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import pandas as pd
import threading
import queue
import sounddevice as sd
import soundfile as sf

# Set page configuration
st.set_page_config(page_title="AI Interview Module", layout="wide")

# Initialize session state variables
if 'questions' not in st.session_state:
    st.session_state.questions = [
        "Tell me about yourself and your background.",
        "Why are you interested in this position?",
        "What are your strengths and weaknesses?",
        "Describe a challenging situation you faced and how you handled it.",
        "Where do you see yourself in 5 years?"
    ]

if 'current_question_index' not in st.session_state:
    st.session_state.current_question_index = 0

if 'interview_completed' not in st.session_state:
    st.session_state.interview_completed = False

if 'transcript' not in st.session_state:
    st.session_state.transcript = ""

if 'sentiment_results' not in st.session_state:
    st.session_state.sentiment_results = None

if 'video_path' not in st.session_state:
    st.session_state.video_path = ""

if 'audio_path' not in st.session_state:
    st.session_state.audio_path = ""

if 'recording' not in st.session_state:
    st.session_state.recording = False

# Header
st.title("AI-Powered Video Interview Module")
st.write("""
### Important Instructions:
1. **Use headphones** to prevent echo/feedback
2. **Mute your speakers** during recording
3. **Allow browser permissions** for camera and microphone
4. **Ensure quiet environment** for best audio quality
""")

# Sidebar for navigation
st.sidebar.title("Interview Module")
options = ["Setup", "Record Interview", "Review & Analyze", "Results"]
choice = st.sidebar.selectbox("Select an option", options)

# Audio Recorder Class
class AudioRecorder:
    def __init__(self):
        self.q = queue.Queue()
        self.recording = False
        self.filename = None
        self.samplerate = 44100
        self.channels = 1

    def callback(self, indata, frames, time, status):
        if status:
            print(status)
        if self.recording:
            self.q.put(indata.copy())

    def start_recording(self, filename):
        self.filename = filename
        self.recording = True
        self.q.queue.clear()  # Clear any old data
        try:
            self.stream = sd.InputStream(
                samplerate=self.samplerate,
                channels=self.channels,
                callback=self.callback
            )
            self.stream.start()
            print("Audio recording started")
        except Exception as e:
            st.error(f"Error starting audio recording: {e}")
            self.recording = False

    def stop_recording(self):
        if self.recording:
            self.recording = False
            self.stream.stop()
            self.stream.close()
            
            # Save the recorded audio
            if not self.q.empty():
                recording = np.concatenate(list(self.q.queue), axis=0)
                sf.write(self.filename, recording, self.samplerate)
                print(f"Audio saved to {self.filename}")
                return self.filename
            else:
                st.warning("No audio data was captured")
                return None
        return None

# Video Recorder Class
class VideoRecorder(VideoTransformerBase):
    def __init__(self):
        self.frames = []
    
    def recv(self, frame):
        img = frame.to_ndarray(format="bgr24")
        self.frames.append(img)
        return frame

# Audio Processor Class
class AudioProcessor(AudioProcessorBase):
    def __init__(self):
        self.audio_data = []
    
    def recv(self, frame):
        self.audio_data.append(frame.to_ndarray())
        return frame

# Function to record video with audio
def record_video():
    st.header("Record Your Interview")
    
    # Display current question
    st.subheader("Current Question:")
    st.write(st.session_state.questions[st.session_state.current_question_index])
    
    # Navigation buttons
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Previous Question") and st.session_state.current_question_index > 0:
            st.session_state.current_question_index -= 1
            st.rerun()
    
    with col2:
        if st.button("Next Question") and st.session_state.current_question_index < len(st.session_state.questions) - 1:
            st.session_state.current_question_index += 1
            st.rerun()
    
    # Initialize audio recorder
    audio_recorder = AudioRecorder()
    
    # Video recording with audio
    st.write("### Recording Instructions:")
    st.write("1. Click 'Start Recording' below")
    st.write("2. Answer the current question")
    st.write("3. Click 'Stop Recording' when finished")
    st.write("4. Use headphones and mute speakers to prevent echo")
    
    # Recording controls
    col1, col2 = st.columns(2)
    
    with col1:
        start_button = st.button("Start Recording")
    
    with col2:
        stop_button = st.button("Stop Recording")
    
    # Start recording
    if start_button:
        st.session_state.recording = True
        st.session_state.audio_path = "interview_audio.wav"
        audio_recorder.start_recording(st.session_state.audio_path)
        st.success("Recording started! Speak now...")
    
    # Video display
    webrtc_ctx = webrtc_streamer(
        key="video-recorder",
        mode=WebRtcMode.SENDRECV,
        video_processor_factory=VideoRecorder,
        audio_processor_factory=AudioProcessor,
        media_stream_constraints={"video": True, "audio": True},
        audio_receiver_size=256
    )
    
    # Stop recording
    if stop_button and st.session_state.recording:
        st.session_state.recording = False
        
        # Stop audio recording
        audio_path = audio_recorder.stop_recording()
        if audio_path:
            st.session_state.audio_path = audio_path
            st.success("Audio recording completed!")
        else:
            st.warning("Audio recording failed")
        
        # Save video
        if webrtc_ctx.video_processor and webrtc_ctx.video_processor.frames:
            # Save video frames
            height, width, _ = webrtc_ctx.video_processor.frames[0].shape
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            video_path = "interview_video.mp4"
            out = cv2.VideoWriter(video_path, fourcc, 20.0, (width, height))
            
            for frame in webrtc_ctx.video_processor.frames:
                out.write(frame)
            
            out.release()
            
            # Combine video and audio
            if os.path.exists(st.session_state.audio_path):
                combined_path = "interview_combined.mp4"
                try:
                    # Use ffmpeg to combine video and audio
                    subprocess.run([
                        'ffmpeg', '-i', video_path, '-i', st.session_state.audio_path,
                        '-c:v', 'copy', '-c:a', 'aac', '-strict', 'experimental',
                        combined_path
                    ], check=True, capture_output=True)
                    
                    st.session_state.video_path = combined_path
                    st.success("Video with audio saved successfully!")
                    
                    # Clean up temporary files
                    os.remove(video_path)
                except subprocess.CalledProcessError as e:
                    st.error(f"Error combining video and audio: {e.stderr.decode('utf-8')}")
                    st.session_state.video_path = video_path
                    st.warning("Video saved without audio due to combining error.")
            else:
                st.session_state.video_path = video_path
                st.warning("Video saved without audio because no audio was recorded.")
        else:
            st.warning("No video frames to save.")
    
    # File uploader for existing videos
    st.subheader("Or Upload Existing Video")
    uploaded_file = st.file_uploader("Upload a video file", type=["mp4", "avi", "mov", "mkv"])
    
    if uploaded_file is not None:
        # Save the uploaded file
        video_path = "uploaded_interview.mp4"
        with open(video_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        st.session_state.video_path = video_path
        st.success("Video uploaded successfully!")
        
        # Check if the uploaded video has audio
        try:
            test_video = VideoFileClip(video_path)
            if test_video.audio is None:
                st.warning("The uploaded video doesn't contain an audio track.")
            else:
                st.success("The uploaded video contains an audio track.")
            test_video.close()
        except Exception as e:
            st.error(f"Error checking video: {str(e)}")

# Function to extract audio and transcribe
def extract_audio_and_transcribe(video_path):
    st.header("Audio Transcription")
    
    if st.button("Extract and Transcribe Audio"):
        with st.spinner("Processing audio..."):
            temp_audio_path = None
            video = None
            
            try:
                # First check if file exists
                if not os.path.exists(video_path):
                    st.error(f"Video file not found: {video_path}")
                    return ""
                
                # Try to extract audio using moviepy
                try:
                    video = VideoFileClip(video_path)
                    
                    # Check if video has audio
                    if video.audio is None:
                        st.warning("MoviePy couldn't detect audio. Trying alternative method...")
                        video.close()
                        video = None
                        
                        # Try using ffmpeg directly
                        temp_audio = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
                        temp_audio_path = temp_audio.name
                        temp_audio.close()
                        
                        # Use ffmpeg to extract audio
                        try:
                            subprocess.run(['ffmpeg', '-i', video_path, '-vn', '-acodec', 'pcm_s16le', 
                                          '-ar', '16000', '-ac', '1', temp_audio_path], 
                                          check=True, capture_output=True)
                            
                            st.success("Audio extracted using ffmpeg!")
                            
                            # Transcribe audio using speech recognition
                            recognizer = sr.Recognizer()
                            with sr.AudioFile(temp_audio_path) as source:
                                audio_data = recognizer.record(source)
                                
                            try:
                                text = recognizer.recognize_google(audio_data)
                                st.success("Transcription completed!")
                                st.session_state.transcript = text
                                
                                # Save transcript
                                with open("interview_transcript.txt", "w") as f:
                                    f.write(text)
                                    
                                return text
                            except sr.UnknownValueError:
                                st.error("Could not understand the audio")
                                return ""
                            except sr.RequestError as e:
                                st.error(f"Error: {e}")
                                return ""
                        except subprocess.CalledProcessError as e:
                            st.error(f"FFmpeg error: {e.stderr.decode('utf-8')}")
                            return ""
                    else:
                        # MoviePy detected audio, proceed with extraction
                        temp_audio = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
                        temp_audio_path = temp_audio.name
                        temp_audio.close()  # Close the file handle
                        
                        # Write audio to temporary file
                        video.audio.write_audiofile(temp_audio_path, logger=None)
                        
                        # Transcribe audio using speech recognition
                        recognizer = sr.Recognizer()
                        with sr.AudioFile(temp_audio_path) as source:
                            audio_data = recognizer.record(source)
                            
                        try:
                            text = recognizer.recognize_google(audio_data)
                            st.success("Transcription completed!")
                            st.session_state.transcript = text
                            
                            # Save transcript
                            with open("interview_transcript.txt", "w") as f:
                                f.write(text)
                                
                            return text
                        except sr.UnknownValueError:
                            st.error("Could not understand the audio")
                            return ""
                        except sr.RequestError as e:
                            st.error(f"Error: {e}")
                            return ""
                except Exception as e:
                    st.error(f"Error processing video: {str(e)}")
                    return ""
            except Exception as e:
                st.error(f"An unexpected error occurred: {str(e)}")
                return ""
            finally:
                # Clean up resources
                if video is not None:
                    video.close()
                
                # Clean up temporary files
                if temp_audio_path is not None and os.path.exists(temp_audio_path):
                    try:
                        os.unlink(temp_audio_path)
                    except PermissionError:
                        st.warning("Could not delete temporary file. It may be in use by another process.")
                    except Exception as e:
                        st.warning(f"Error cleaning up temporary file: {str(e)}")

# Function to analyze sentiment
def analyze_sentiment(text):
    st.header("Sentiment Analysis")
    
    if st.button("Analyze Sentiment"):
        with st.spinner("Analyzing sentiment..."):
            # Load the sentiment analysis pipeline
            sentiment_pipeline = pipeline("sentiment-analysis")
            
            # Split text into chunks if it's too long
            max_chunk_size = 512
            chunks = [text[i:i+max_chunk_size] for i in range(0, len(text), max_chunk_size)]
            
            results = []
            for chunk in chunks:
                result = sentiment_pipeline(chunk)[0]
                results.append(result)
            
            # Calculate average sentiment
            avg_score = sum(r['score'] for r in results) / len(results)
            
            # Determine overall sentiment
            positive_count = sum(1 for r in results if r['label'] == 'POSITIVE')
            overall_sentiment = "POSITIVE" if positive_count > len(results)/2 else "NEGATIVE"
            
            # Store results
            st.session_state.sentiment_results = {
                "overall_sentiment": overall_sentiment,
                "confidence": avg_score,
                "detailed_results": results
            }
            
            # Display results
            st.subheader("Overall Sentiment:")
            st.write(f"Label: {overall_sentiment}")
            st.write(f"Confidence: {avg_score:.2f}")
            
            # Detailed results
            st.subheader("Detailed Analysis:")
            for i, result in enumerate(results):
                st.write(f"Chunk {i+1}: {result['label']} (Score: {result['score']:.2f})")
            
            return st.session_state.sentiment_results

# Function to generate PDF report
def generate_pdf_report(candidate_id, interview_results):
    filename = f"interview_report_{candidate_id}.pdf"
    c = canvas.Canvas(filename, pagesize=letter)
    
    # Add content to the PDF
    c.drawString(100, 750, f"Interview Report for Candidate: {candidate_id}")
    c.drawString(100, 730, f"Date: {time.strftime('%Y-%m-%d')}")
    c.drawString(100, 710, f"Overall Sentiment: {interview_results['sentiment']['overall_sentiment']}")
    c.drawString(100, 690, f"Confidence Score: {interview_results['sentiment']['confidence']:.2f}")
    
    # Add transcript excerpt
    c.drawString(100, 650, "Transcript Excerpt:")
    transcript_excerpt = interview_results['transcript'][:200] + "..." if len(interview_results['transcript']) > 200 else interview_results['transcript']
    c.drawString(100, 630, transcript_excerpt)
    
    c.save()
    return filename

# Function to display interview questions
def interview_questions():
    st.header("Interview Questions")
    
    # Display questions
    st.subheader("Current Questions:")
    for i, question in enumerate(st.session_state.questions):
        st.write(f"{i+1}. {question}")
    
    # Add new question
    with st.expander("Add New Question"):
        new_question = st.text_input("Enter a new question:")
        if st.button("Add Question"):
            if new_question:
                st.session_state.questions.append(new_question)
                st.success("Question added!")
                st.rerun()
            else:
                st.error("Please enter a question")

# Main application logic
def main():
    if choice == "Setup":
        st.header("Interview Setup")
        interview_questions()
        
    elif choice == "Record Interview":
        record_video()
        
    elif choice == "Review & Analyze":
        st.header("Review and Analyze Interview")
        
        if st.session_state.video_path:
            # Display the video
            st.video(st.session_state.video_path)
            
            # Extract and transcribe audio
            if not st.session_state.transcript:
                extract_audio_and_transcribe(st.session_state.video_path)
            else:
                st.subheader("Interview Transcript:")
                st.write(st.session_state.transcript)
            
            # Analyze sentiment
            if st.session_state.transcript and not st.session_state.sentiment_results:
                analyze_sentiment(st.session_state.transcript)
            elif st.session_state.sentiment_results:
                st.subheader("Sentiment Analysis Results:")
                st.write(f"Overall Sentiment: {st.session_state.sentiment_results['overall_sentiment']}")
                st.write(f"Confidence: {st.session_state.sentiment_results['confidence']:.2f}")
        else:
            st.warning("No interview video found. Please record or upload a video first.")
    
    elif choice == "Results":
        st.header("Interview Results")
        
        if st.session_state.transcript and st.session_state.sentiment_results:
            # Display comprehensive results
            st.subheader("Interview Summary")
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Overall Sentiment", st.session_state.sentiment_results['overall_sentiment'])
            
            with col2:
                st.metric("Confidence Score", f"{st.session_state.sentiment_results['confidence']:.2f}")
            
            # Option to save results
            candidate_id = st.text_input("Enter Candidate ID:")
            if st.button("Save Interview Results"):
                if candidate_id:
                    # Create a results dictionary
                    results = {
                        "candidate_id": candidate_id,
                        "transcript": st.session_state.transcript,
                        "sentiment": st.session_state.sentiment_results,
                        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
                    }
                    
                    # Save to JSON file
                    with open(f"interview_results_{candidate_id}.json", "w") as f:
                        json.dump(results, f)
                    
                    # Generate PDF report
                    pdf_path = generate_pdf_report(candidate_id, results)
                    
                    st.success(f"Results saved successfully! PDF report generated: {pdf_path}")
                    
                    # Mark interview as completed
                    st.session_state.interview_completed = True
                else:
                    st.error("Please enter a Candidate ID")
        else:
            st.warning("No interview data available. Please complete an interview first.")

if __name__ == "__main__":
    main()