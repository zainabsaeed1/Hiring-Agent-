import cv2
import numpy as np
from PIL import Image
import os
from datetime import datetime
from skimage.metrics import structural_similarity as ssim
import pickle

class SimpleFaceMatcher:
    def __init__(self):
        # Load OpenCV's pre-trained face cascade
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
        
        # Parameters
        self.min_face_size = (50, 50)
        self.scale_factor = 1.1
        self.min_neighbors = 5
        
    def detect_face(self, image):
        """
        Detect and extract the largest face from image
        
        Args:
            image: Input image (BGR or RGB)
            
        Returns:
            tuple: (success, face_region or error_message, face_coordinates)
        """
        try:
            # Convert to grayscale for face detection
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image
            
            # Detect faces
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=self.scale_factor,
                minNeighbors=self.min_neighbors,
                minSize=self.min_face_size,
                flags=cv2.CASCADE_SCALE_IMAGE
            )
            
            if len(faces) == 0:
                return False, "No face detected in image", None
            
            if len(faces) > 1:
                # Find the largest face
                areas = [(w * h, i) for i, (x, y, w, h) in enumerate(faces)]
                largest_face_idx = max(areas)[1]
                face = faces[largest_face_idx]
                print(f"Multiple faces detected, using the largest one")
            else:
                face = faces[0]
            
            x, y, w, h = face
            
            # Extract face region with some padding
            padding = 20
            x_start = max(0, x - padding)
            y_start = max(0, y - padding)
            x_end = min(image.shape[1], x + w + padding)
            y_end = min(image.shape[0], y + h + padding)
            
            face_region = image[y_start:y_end, x_start:x_end]
            
            # Verify we have eyes in the face (basic quality check)
            face_gray = cv2.cvtColor(face_region, cv2.COLOR_BGR2GRAY) if len(face_region.shape) == 3 else face_region
            eyes = self.eye_cascade.detectMultiScale(face_gray)
            
            quality_score = len(eyes) / 2.0  # Ideal is 2 eyes
            
            return True, face_region, {
                'coordinates': (x, y, w, h),
                'padded_coordinates': (x_start, y_start, x_end, y_end),
                'quality_score': min(1.0, quality_score),
                'eyes_detected': len(eyes)
            }
            
        except Exception as e:
            return False, f"Error detecting face: {str(e)}", None
    
    def extract_face_features(self, face_region):
        """
        Extract simple features from face region
        
        Args:
            face_region: Cropped face image
            
        Returns:
            numpy array: Feature vector
        """
        try:
            # Resize to standard size
            standard_size = (100, 100)
            face_resized = cv2.resize(face_region, standard_size)
            
            # Convert to grayscale
            if len(face_resized.shape) == 3:
                face_gray = cv2.cvtColor(face_resized, cv2.COLOR_BGR2GRAY)
            else:
                face_gray = face_resized
            
            # Normalize pixel values
            face_normalized = face_gray.astype(np.float32) / 255.0
            
            # Create feature vector using histogram and edge features
            # 1. Histogram features
            hist = cv2.calcHist([face_gray], [0], None, [32], [0, 256])
            hist_normalized = hist.flatten() / hist.sum()
            
            # 2. Edge features using Sobel
            sobel_x = cv2.Sobel(face_gray, cv2.CV_64F, 1, 0, ksize=3)
            sobel_y = cv2.Sobel(face_gray, cv2.CV_64F, 0, 1, ksize=3)
            edge_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
            edge_hist = cv2.calcHist([edge_magnitude.astype(np.uint8)], [0], None, [16], [0, 256])
            edge_hist_normalized = edge_hist.flatten() / edge_hist.sum()
            
            # 3. LBP-like features (simplified)
            lbp_features = self.simple_lbp(face_gray)
            
            # Combine all features
            features = np.concatenate([
                hist_normalized,
                edge_hist_normalized,
                lbp_features,
                face_normalized.flatten()[::10]  # Downsample raw pixels
            ])
            
            return features
            
        except Exception as e:
            print(f"Error extracting features: {e}")
            return None
    
    def simple_lbp(self, image, radius=1):
        """Simple Local Binary Pattern features"""
        height, width = image.shape
        lbp = np.zeros((height-2*radius, width-2*radius), dtype=np.uint8)
        
        for i in range(radius, height-radius):
            for j in range(radius, width-radius):
                center = image[i, j]
                code = 0
                code |= (image[i-1, j-1] >= center) << 0
                code |= (image[i-1, j] >= center) << 1
                code |= (image[i-1, j+1] >= center) << 2
                code |= (image[i, j+1] >= center) << 3
                code |= (image[i+1, j+1] >= center) << 4
                code |= (image[i+1, j] >= center) << 5
                code |= (image[i+1, j-1] >= center) << 6
                code |= (image[i, j-1] >= center) << 7
                lbp[i-radius, j-radius] = code
        
        # Create histogram of LBP codes
        hist = cv2.calcHist([lbp], [0], None, [16], [0, 256])
        return hist.flatten() / hist.sum()
    
    def compare_faces(self, reference_image, live_image):
        """
        Compare two face images
        
        Args:
            reference_image: Reference image array
            live_image: Live image array
            
        Returns:
            dict: Comparison results
        """
        try:
            # Detect faces in both images
            ref_success, ref_face, ref_info = self.detect_face(reference_image)
            if not ref_success:
                return {
                    "success": False,
                    "match": False,
                    "confidence": 0.0,
                    "message": f"Reference image: {ref_face}",
                    "faces_found": 0
                }
            
            live_success, live_face, live_info = self.detect_face(live_image)
            if not live_success:
                return {
                    "success": False,
                    "match": False,
                    "confidence": 0.0,
                    "message": f"Live image: {live_face}",
                    "faces_found": 0
                }
            
            # Extract features
            ref_features = self.extract_face_features(ref_face)
            live_features = self.extract_face_features(live_face)
            
            if ref_features is None or live_features is None:
                return {
                    "success": False,
                    "match": False,
                    "confidence": 0.0,
                    "message": "Could not extract face features",
                    "faces_found": 1
                }
            
            # Calculate multiple similarity metrics
            # 1. Cosine similarity
            cosine_sim = np.dot(ref_features, live_features) / (
                np.linalg.norm(ref_features) * np.linalg.norm(live_features)
            )
            
            # 2. Structural similarity on resized faces
            ref_gray = cv2.cvtColor(cv2.resize(ref_face, (100, 100)), cv2.COLOR_BGR2GRAY)
            live_gray = cv2.cvtColor(cv2.resize(live_face, (100, 100)), cv2.COLOR_BGR2GRAY)
            ssim_score = ssim(ref_gray, live_gray)
            
            # 3. Euclidean distance (inverted and normalized)
            euclidean_dist = np.linalg.norm(ref_features - live_features)
            max_possible_dist = np.sqrt(len(ref_features))
            euclidean_sim = 1.0 - (euclidean_dist / max_possible_dist)
            
            # Combine metrics with weights
            combined_score = (
                0.4 * cosine_sim +
                0.4 * ssim_score +
                0.2 * euclidean_sim
            )
            
            confidence = max(0, min(100, combined_score * 100))
            
            # Quality check
            quality_factor = (ref_info['quality_score'] + live_info['quality_score']) / 2.0
            adjusted_confidence = confidence * (0.7 + 0.3 * quality_factor)
            
            # Determine match (adjustable threshold)
            threshold = 65.0
            is_match = adjusted_confidence >= threshold
            
            if is_match:
                status = "VERIFIED"
                message = f"Identity verified! Confidence: {adjusted_confidence:.1f}%"
            else:
                status = "NOT VERIFIED"
                message = f"Identity not verified. Confidence: {adjusted_confidence:.1f}%"
            
            return {
                "success": True,
                "match": is_match,
                "confidence": adjusted_confidence,
                "raw_confidence": confidence,
                "cosine_similarity": cosine_sim,
                "ssim_score": ssim_score,
                "euclidean_similarity": euclidean_sim,
                "quality_score": quality_factor,
                "status": status,
                "message": message,
                "faces_found": 1,
                "reference_quality": ref_info,
                "live_quality": live_info,
                "timestamp": datetime.now().isoformat(),
                "method": "opencv_multifeature"
            }
            
        except Exception as e:
            return {
                "success": False,
                "match": False,
                "confidence": 0.0,
                "message": f"Error during comparison: {str(e)}",
                "faces_found": 0
            }
    
    def load_image(self, image_path):
        """Load image from file"""
        try:
            if isinstance(image_path, str):
                image = cv2.imread(image_path)
                if image is None:
                    return False, "Could not load image file"
            else:
                image = image_path
            
            return True, image
            
        except Exception as e:
            return False, f"Error loading image: {str(e)}"
    
    def capture_live_image(self, save_path=None):
        """Capture image from webcam"""
        try:
            cap = cv2.VideoCapture(0)
            
            if not cap.isOpened():
                return False, "Could not access webcam"
            
            print("Camera warming up...")
            # Let camera warm up and auto-adjust
            for i in range(30):
                ret, frame = cap.read()
                if i % 10 == 0:
                    print(f"Warming up... {i//10 + 1}/3")
            
            print("Capturing image in 3...")
            for countdown in [2, 1]:
                ret, frame = cap.read()
                print(f"{countdown}...")
                cv2.waitKey(1000)
            
            print("Capturing now!")
            ret, frame = cap.read()
            cap.release()
            
            if not ret:
                return False, "Could not capture image from webcam"
            
            # Save image if path provided
            if save_path:
                cv2.imwrite(save_path, frame)
                print(f"Image saved to: {save_path}")
            
            return True, frame
            
        except Exception as e:
            return False, f"Error capturing live image: {str(e)}"
    
    def verify_identity(self, reference_image_path, live_image_path=None, capture_live=True):
        """Complete verification process"""
        print(f"Loading reference image: {reference_image_path}")
        
        # Load reference image
        ref_success, ref_image = self.load_image(reference_image_path)
        if not ref_success:
            return {
                "success": False,
                "error": f"Reference image error: {ref_image}",
                "stage": "reference_loading"
            }
        
        # Get live image
        if capture_live:
            print("Preparing to capture live image...")
            os.makedirs("test_images/captured", exist_ok=True)
            save_path = f"test_images/captured/live_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
            
            live_success, live_image = self.capture_live_image(save_path)
            if not live_success:
                return {
                    "success": False,
                    "error": f"Live capture error: {live_image}",
                    "stage": "live_capture"
                }
        else:
            if not live_image_path or not os.path.exists(live_image_path):
                return {
                    "success": False,
                    "error": "Live image path not provided or file doesn't exist",
                    "stage": "live_image_loading"
                }
            
            live_success, live_image = self.load_image(live_image_path)
            if not live_success:
                return {
                    "success": False,
                    "error": f"Live image error: {live_image}",
                    "stage": "live_image_loading"
                }
        
        print("Comparing faces...")
        # Compare faces
        result = self.compare_faces(ref_image, live_image)
        
        # Add metadata
        result["reference_image"] = reference_image_path
        result["verification_method"] = "webcam_capture" if capture_live else "file_upload"
        
        return result

def test_simple_matcher():
    """Test the simple face matcher"""
    matcher = SimpleFaceMatcher()
    
    print("=== Simple OpenCV Face Matcher Test ===")
    print("Requirements:")
    print("1. Reference image in 'test_images/reference/' folder")
    print("2. Working webcam")
    print()
    
    # Create directories
    os.makedirs("test_images/reference", exist_ok=True)
    os.makedirs("test_images/captured", exist_ok=True)
    
    # Look for reference images
    ref_files = [f for f in os.listdir("test_images/reference") 
                if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp'))]
    
    if not ref_files:
        print("❌ No reference images found!")
        print("Please add a reference image to 'test_images/reference/' folder")
        print("Supported formats: jpg, jpeg, png, bmp")
        return
    
    reference_path = f"test_images/reference/{ref_files[0]}"
    print(f"✅ Using reference image: {reference_path}")
    
    # Test face detection on reference image
    ref_success, ref_image = matcher.load_image(reference_path)
    if ref_success:
        face_success, face_result, face_info = matcher.detect_face(ref_image)
        if face_success:
            print(f"✅ Face detected in reference image")
            print(f"   Quality score: {face_info['quality_score']:.2f}")
            print(f"   Eyes detected: {face_info['eyes_detected']}")
        else:
            print(f"❌ No face in reference image: {face_result}")
            return
    
    # Start verification
    print("\n" + "="*50)
    print("STARTING IDENTITY VERIFICATION")
    print("="*50)
    
    input("\n📷 Press Enter when ready to capture your photo...")
    
    result = matcher.verify_identity(reference_path, capture_live=True)
    
    print("\n" + "="*30)
    print("VERIFICATION RESULTS")
    print("="*30)
    
    if result.get("success"):
        print(f"🎯 Status: {result['status']}")
        print(f"✅ Match: {'YES' if result['match'] else 'NO'}")
        print(f"📊 Confidence: {result['confidence']:.1f}%")
        print(f"💬 Message: {result['message']}")
        print(f"🔍 Method: {result['method']}")
        
        print(f"\n📈 Detailed Metrics:")
        print(f"   Raw Confidence: {result.get('raw_confidence', 0):.1f}%")
        print(f"   Cosine Similarity: {result.get('cosine_similarity', 0):.3f}")
        print(f"   SSIM Score: {result.get('ssim_score', 0):.3f}")
        print(f"   Quality Score: {result.get('quality_score', 0):.3f}")
        
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")
        print(f"📍 Stage: {result.get('stage', 'Unknown')}")
    
    print(f"\n💾 Images saved in: test_images/captured/")

if __name__ == "__main__":
    test_simple_matcher()