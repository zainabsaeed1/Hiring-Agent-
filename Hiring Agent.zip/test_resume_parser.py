import streamlit as st
import io
import json
from datetime import datetime
from resume_parser import parse_resume, extract_text_from_file, SKILLS_DB
from jd_matcher import compute_match_score, extract_jd_skills, generate_suggestions, extract_experience_from_jd

def main():
    # Set up the page
    st.set_page_config(
        page_title="Resume-JD Matcher",
        page_icon="📄",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Header
    st.title("📄 Resume-JD Matching Tool")
    st.markdown("Upload your resume and enter a job description to see how well they match.")
    
    # Sidebar for inputs
    st.sidebar.header("Upload & Input")
    
    # File upload
    uploaded_file = st.sidebar.file_uploader(
        "Upload your resume (PDF or DOCX)",
        type=["pdf", "docx"],
        help="Upload your resume in PDF or DOCX format"
    )
    
    # Job description input
    jd_text = st.sidebar.text_area(
        "Enter Job Description",
        height=300,
        help="Paste the job description text here"
    )
    
    # Process button
    process_button = st.sidebar.button("Analyze Match", type="primary")
    
    # Main content area
    if process_button:
        if uploaded_file is None:
            st.error("Please upload a resume file.")
            return
        
        if not jd_text.strip():
            st.error("Please enter a job description.")
            return
        
        # Process the file
        with st.spinner("Processing your resume..."):
            # Create a file-like object from the uploaded file
            file_type = uploaded_file.type
            file_content = uploaded_file.read()
            
            # Create a BytesIO object
            file_obj = io.BytesIO(file_content)
            file_obj.type = file_type
            
            # Parse the resume
            parsed_resume = parse_resume(file_obj)
            
            if "error" in parsed_resume:
                st.error(f"Error parsing resume: {parsed_resume['error']}")
                return
            
            # Extract text from resume
            file_obj.seek(0)  # Reset the file pointer
            resume_text = extract_text_from_file(file_obj)
            
            if isinstance(resume_text, str) and resume_text.startswith("Error"):
                st.error(f"Error extracting text from resume: {resume_text}")
                return
            
            # Compute match score
            result = compute_match_score(resume_text, jd_text, parsed_resume)
            
            # Display results
            display_results(result, parsed_resume, uploaded_file.name)
    
    # Instructions when no results yet
    if not process_button:
        st.info("👆 Upload your resume and enter a job description, then click 'Analyze Match' to see the results.")

def display_results(result, parsed_resume, filename):
    # Display overall match score with a progress bar
    st.header("Matching Results")
    
    col1, col2 = st.columns([1, 3])
    
    with col1:
        st.metric(
            label="Match Score",
            value=f"{result['overall_score']}%",
            delta=None,
            delta_color="normal"
        )
    
    with col2:
        st.progress(result['overall_score'] / 100)
    
    # Display feedback
    st.subheader("Feedback")
    st.markdown(f"**{result['feedback']}**")
    
    # Display score breakdown
    st.subheader("Score Breakdown")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Semantic", f"{result['semantic_score']}%")
    
    with col2:
        if result["skills_match"] is not None:
            st.metric("Skills", f"{result['skills_match']}%")
        else:
            st.metric("Skills", "N/A")
    
    with col3:
        if result["experience_match"] is not None:
            st.metric("Experience", f"{result['experience_match']}%")
        else:
            st.metric("Experience", "N/A")
    
    with col4:
        if result["education_match"] is not None:
            st.metric("Education", f"{result['education_match']}%")
        else:
            st.metric("Education", "N/A")
    
    # Display score explanation
    st.subheader("Score Analysis")
    for explanation in result["score_explanation"]:
        st.markdown(explanation)
    
    # Display skills analysis
    st.subheader("Skills Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Skills Found in Resume")
        resume_skills = []
        for category in parsed_resume['skills'].values():
            resume_skills.extend(category)
        st.write(", ".join(resume_skills) if resume_skills else "No skills identified")
    
    with col2:
        st.markdown("#### Missing Skills")
        st.write(", ".join(result["missing_skills"]) if result["missing_skills"] else "All required skills found in resume")
    
    # Display suggestions
    st.subheader("Suggestions to Improve Your Resume")
    
    if result["suggestions"]:
        for suggestion in result["suggestions"]:
            priority_color = {
                "high": "🔴",
                "medium": "🟡",
                "low": "🟢"
            }.get(suggestion["priority"], "⚪")
            
            with st.expander(f"{priority_color} {suggestion['type']} Improvement"):
                st.markdown(suggestion["message"])
    else:
        st.success("Your resume is well-aligned with the job description! No major improvements needed.")
    
    # Display parsed resume data in an expandable section
    with st.expander("View Parsed Resume Data"):
        st.json(parsed_resume)
    
    # Option to download results
    st.subheader("Export Results")
    
    # Prepare results data
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    report = {
        "timestamp": timestamp,
        "resume_file": filename,
        "overall_score": result["overall_score"],
        "semantic_score": result["semantic_score"],
        "skills_match": result["skills_match"],
        "experience_match": result["experience_match"],
        "education_match": result["education_match"],
        "feedback": result["feedback"],
        "missing_skills": result["missing_skills"],
        "suggestions": result["suggestions"],
        "score_explanation": result["score_explanation"],
        "parsed_resume": parsed_resume
    }
    
    # Create download button
    st.download_button(
        label="Download Results as JSON",
        data=json.dumps(report, indent=2),
        file_name=f"resume_match_report_{timestamp.replace(':', '-')}.json",
        mime="application/json"
    )

if __name__ == "__main__":
    main()