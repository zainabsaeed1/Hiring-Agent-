import spacy
from spacy.matcher import PhraseMatcher
import re
import io
import json
from datetime import datetime

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_lg")
except OSError:
    print("Error: spaCy model 'en_core_web_lg' not found. Please install it with: python -m spacy download en_core_web_lg")
    nlp = None

# Initialize matchers
if nlp:
    skill_matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
    cert_matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
    lang_matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
else:
    skill_matcher = cert_matcher = lang_matcher = None

# Load comprehensive skill database
try:
    with open('skills_database.json', 'r') as f:
        SKILLS_DB = json.load(f)
except FileNotFoundError:
    # Fallback to basic skill list
    SKILLS_DB = {
        "technical": ["Python", "Java", "JavaScript", "C++", "SQL", "HTML", "CSS", "React"],
        "soft": ["Communication", "Leadership", "Teamwork", "Problem Solving", "Time Management"]
    }

# Comprehensive certification list
CERTIFICATIONS = [
    "AWS Certified Solutions Architect", "Microsoft Certified: Azure Administrator",
    "Certified Kubernetes Administrator (CKA)", "PMP", "Scrum Master",
    "Google Cloud Professional", "Cisco Certified Network Associate (CCNA)",
    "Certified Information Systems Security Professional (CISSP)"
]

# Language list
LANGUAGES = [
    "English", "Spanish", "French", "German", "Chinese", "Japanese", "Korean",
    "Russian", "Arabic", "Hindi", "Portuguese", "Italian"
]

# Add patterns to matchers if nlp is available
if skill_matcher:
    all_skills = []
    for category in SKILLS_DB.values():
        all_skills.extend(category)
    skill_patterns = [nlp.make_doc(skill.lower()) for skill in all_skills]
    skill_matcher.add("SKILLS", skill_patterns)
    
    cert_patterns = [nlp.make_doc(cert.lower()) for cert in CERTIFICATIONS]
    cert_matcher.add("CERTIFICATIONS", cert_patterns)
    
    lang_patterns = [nlp.make_doc(lang.lower()) for lang in LANGUAGES]
    lang_matcher.add("LANGUAGES", lang_patterns)

# Import pdfplumber for PDF text extraction
try:
    import pdfplumber
except ImportError:
    pdfplumber = None
    print("Warning: pdfplumber not installed. Please install it with: pip install pdfplumber")

# Import docx with error handling
Document = None
try:
    from docx import Document
except ImportError as e:
    print(f"Warning: Failed to import python-docx: {e}")

def extract_text_from_file(file):
    """Extract text from PDF or DOCX file with improved error handling"""
    if file.type == "application/pdf":
        if pdfplumber is None:
            return "Error: pdfplumber is not installed. Please install it with: pip install pdfplumber"
        try:
            pdf_content = file.read()
            with pdfplumber.open(io.BytesIO(pdf_content)) as pdf:
                text = ""
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
            return text if text.strip() else "Error: No text could be extracted from the PDF"
        except Exception as e:
            return f"Error extracting PDF text: {str(e)}"
            
    elif file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        if Document is None:
            return "Error: python-docx is not installed. Please install it with: pip install python-docx"
        try:
            doc = Document(io.BytesIO(file.read()))
            return "\n".join([para.text for para in doc.paragraphs if para.text.strip()])
        except Exception as e:
            return f"Error extracting DOCX text: {str(e)}"
            
    else:
        return "Error: Unsupported file type. Only PDF and DOCX files are supported."

def parse_resume(file):
    """Enhanced resume parsing with more accurate extraction"""
    if nlp is None:
        return {"error": "spaCy model not loaded. Please install en_core_web_lg model."}
    
    try:
        # Extract text from file
        text = extract_text_from_file(file)
        if isinstance(text, str) and text.startswith("Error"):
            return {"error": text}
            
        doc = nlp(text)
        
        # Initialize result dictionary with enhanced structure
        result = {
            "personal_info": {
                "name": [],
                "email": [],
                "phone": []
            },
            "skills": {
                "technical": [],
                "soft": []
            },
            "experience": [],
            "education": [],
            "certifications": [],
            "languages": [],
            "links": [],
            "organizations": [],
            "total_experience": None
        }
        
        # Extract personal information
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                result["personal_info"]["name"].append(ent.text)
            elif ent.label_ == "EMAIL":
                result["personal_info"]["email"].append(ent.text)
            elif ent.label_ == "PHONE":
                result["personal_info"]["phone"].append(ent.text)
            elif ent.label_ == "ORG":
                result["organizations"].append(ent.text)
            elif ent.label_ == "GPE":
                result["links"].append(ent.text)
        
        # Extract skills with categorization
        if skill_matcher:
            skill_matches = skill_matcher(doc)
            matched_skills = set()
            for match_id, start, end in skill_matches:
                span = doc[start:end]
                matched_skills.add(span.text.lower())
            
            # Categorize skills
            for skill in matched_skills:
                categorized = False
                for category, skills in SKILLS_DB.items():
                    if skill in [s.lower() for s in skills]:
                        result["skills"][category].append(skill)
                        categorized = True
                        break
                if not categorized:
                    result["skills"]["technical"].append(skill)  # Default to technical
        else:
            # Fallback: simple keyword matching
            text_lower = text.lower()
            for category, skills in SKILLS_DB.items():
                result["skills"][category] = [skill for skill in skills if skill.lower() in text_lower]
        
        # Extract certifications
        if cert_matcher:
            cert_matches = cert_matcher(doc)
            result["certifications"] = list(set([doc[start:end].text for _, start, end in cert_matches]))
        
        # Extract languages
        if lang_matcher:
            lang_matches = lang_matcher(doc)
            result["languages"] = list(set([doc[start:end].text for _, start, end in lang_matches]))
        
        # Extract education with improved patterns
        education_patterns = [
            r"(?i)(bachelor|b\.s\.|b\.a\.|undergraduate)[\s\w]*in\s*([\w\s]+)",
            r"(?i)(master|m\.s\.|m\.a\.|graduate)[\s\w]*in\s*([\w\s]+)",
            r"(?i)(phd|doctorate|doctoral)[\s\w]*in\s*([\w\s]+)",
            r"(?i)(associate|a\.a\.|a\.s\.)[\s\w]*in\s*([\w\s]+)"
        ]
        
        for pattern in education_patterns:
            matches = re.findall(pattern, text)
            for degree, field in matches:
                result["education"].append(f"{degree.strip()} in {field.strip()}")
        
        # Extract experience with structured data
        experience_sections = extract_experience_sections(text)
        for section in experience_sections:
            exp_data = parse_experience_section(section)
            if exp_data:
                result["experience"].append(exp_data)
        
        # Calculate total experience
        result["total_experience"] = calculate_total_experience(result["experience"])
        
        # Clean and deduplicate results
        clean_results(result)
        
        return result
    
    except Exception as e:
        return {"error": str(e)}

def extract_experience_sections(text):
    """Extract experience sections from resume text"""
    # Common section headers
    experience_headers = [
        "experience", "work experience", "employment history", 
        "professional experience", "work history", "career"
    ]
    
    sections = []
    text_lower = text.lower()
    
    for header in experience_headers:
        start_idx = text_lower.find(header)
        if start_idx != -1:
            # Find the end of this section (next section or end of document)
            end_idx = len(text)
            for next_header in ["education", "skills", "certifications", "projects", "languages"]:
                next_idx = text_lower.find(next_header, start_idx + len(header))
                if next_idx != -1 and next_idx < end_idx:
                    end_idx = next_idx
            
            sections.append(text[start_idx:end_idx].strip())
    
    return sections

def parse_experience_section(section_text):
    """Parse a single experience section into structured data"""
    # Pattern to match job entries
    job_pattern = r"(?i)([^\n]+?)\s*\|\s*([^\n]+?)\s*\|\s*(\d{1,2}/\d{4}\s*-\s*(\d{1,2}/\d{4}|present))"
    
    matches = re.findall(job_pattern, section_text)
    experiences = []
    
    for match in matches:
        job_title, company, duration, _ = match
        experiences.append({
            "title": job_title.strip(),
            "company": company.strip(),
            "duration": duration.strip(),
            "years": calculate_experience_years(duration)
        })
    
    return experiences if experiences else None

def calculate_experience_years(duration_str):
    """Calculate years of experience from duration string"""
    try:
        start_str, end_str = duration_str.split('-')
        start_date = datetime.strptime(start_str.strip(), "%m/%Y")
        
        if end_str.strip().lower() == "present":
            end_date = datetime.now()
        else:
            end_date = datetime.strptime(end_str.strip(), "%m/%Y")
        
        # Calculate years difference
        years = (end_date - start_date).days / 365.25
        return round(years, 1)
    except:
        return None

def calculate_total_experience(experiences):
    """Calculate total years of experience from all jobs"""
    if not experiences:
        return None
    
    total_years = 0
    for exp_list in experiences:
        if isinstance(exp_list, list):
            for exp in exp_list:
                if exp.get("years"):
                    total_years += exp["years"]
    
    return round(total_years, 1) if total_years > 0 else None

def clean_results(result):
    """Clean and deduplicate results"""
    for key in result:
        if isinstance(result[key], dict):
            for sub_key in result[key]:
                if isinstance(result[key][sub_key], list):
                    result[key][sub_key] = list(set(item.strip() for item in result[key][sub_key] if item.strip()))
        elif isinstance(result[key], list):
            result[key] = list(set(item.strip() for item in result[key] if item.strip()))

def extract_resume_sections(text):
    """Extract major sections of the resume with improved patterns"""
    section_patterns = {
        "summary": r"(?i)(summary|profile|objective|about me|professional summary)",
        "experience": r"(?i)(experience|work history|employment|professional experience)",
        "education": r"(?i)(education|academic|qualification|degrees)",
        "skills": r"(?i)(skills|competencies|expertise|technical skills)",
        "projects": r"(?i)(projects|portfolio|project experience)",
        "certifications": r"(?i)(certifications|licenses|credentials)",
        "languages": r"(?i)(languages|proficiencies|language skills)"
    }
    
    sections = {}
    for section_name, pattern in section_patterns.items():
        match = re.search(pattern, text)
        if match:
            start = match.start()
            # Find next section or end of document
            next_section = None
            for other_pattern in section_patterns.values():
                other_match = re.search(other_pattern, text[match.end():])
                if other_match and (next_section is None or other_match.start() < next_section):
                    next_section = other_match.start()
            
            if next_section is not None:
                end = match.end() + next_section
            else:
                end = len(text)
            
            sections[section_name] = text[start:end].strip()
    
    return sections

def get_resume_summary(text):
    """Generate a professional summary of the resume"""
    if nlp is None:
        return text[:200] + "..."
    
    doc = nlp(text)
    
    # Extract key sentences with professional keywords
    important_sentences = []
    for sent in doc.sents:
        # Check for important keywords
        if any(keyword in sent.text.lower() for keyword in 
               ["experience", "skilled", "expert", "proficient", "developed", "managed", 
                "led", "achieved", "implemented", "specialized"]):
            important_sentences.append(sent.text)
    
    # Return first 3 important sentences as summary
    if important_sentences:
        summary = " ".join(important_sentences[:3])
        return summary if len(summary) > 100 else text[:200] + "..."
    return text[:200] + "..."

# Example usage
if __name__ == "__main__":
    # Test with a sample file
    try:
        with open("sample_resume.pdf", "rb") as f:
            sample_file = io.BytesIO(f.read())
            sample_file.type = "application/pdf"
            
            parsed_data = parse_resume(sample_file)
            print("Parsed Data:")
            print(json.dumps(parsed_data, indent=2))
            
            # Extract sections
            text = extract_text_from_file(sample_file)
            sections = extract_resume_sections(text)
            print("\nSections Found:")
            for section, content in sections.items():
                print(f"{section.upper()}: {content[:100]}...")
            
            # Get summary
            summary = get_resume_summary(text)
            print("\nSummary:", summary)
    except FileNotFoundError:
        print("Sample file not found. Please provide a sample resume file for testing.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")