from sentence_transformers import SentenceTransformer, util
import re
import spacy
import json
from datetime import datetime

# Load more accurate model
model = SentenceTransformer('paraphrase-mpnet-base-v2')

# Load spaCy model for advanced text processing
try:
    nlp = spacy.load("en_core_web_lg")
except OSError:
    print("Warning: spaCy model not found. Using basic text processing.")
    nlp = None

# Load comprehensive skill database
try:
    with open('skills_database.json', 'r') as f:
        SKILLS_DB = json.load(f)
except FileNotFoundError:
    # Fallback to basic skill list
    SKILLS_DB = {
        "technical": [
            "Python", "Java", "JavaScript", "C++", "SQL", "HTML", "CSS", "React",
            "Angular", "Node.js", "Machine Learning", "Data Analysis", "TensorFlow",
            "PyTorch", "AWS", "Azure", "Docker", "Kubernetes", "Git", "CI/CD",
            "Project Management", "Agile", "Scrum"
        ],
        "soft": [
            "Communication", "Leadership", "Teamwork", "Problem Solving",
            "Time Management", "Critical Thinking", "Adaptability", "Creativity",
            "Collaboration", "Conflict Resolution", "Decision Making", "Emotional Intelligence"
        ]
    }

def compute_match_score(resume_text, jd_text, resume_data=None):
    """Compute overall match score between resume and job description"""
    # Preprocess texts
    resume_text = preprocess_text(resume_text)
    jd_text = preprocess_text(jd_text)
    
    # Calculate embeddings
    resume_embedding = model.encode(resume_text, convert_to_tensor=True)
    jd_embedding = model.encode(jd_text, convert_to_tensor=True)
    
    # Calculate semantic similarity
    semantic_similarity = util.pytorch_cos_sim(resume_embedding, jd_embedding).item()
    semantic_score = round(semantic_similarity * 100, 2)
    
    # Extract skills from both documents
    jd_skills = extract_jd_skills(jd_text, SKILLS_DB)
    resume_skills = extract_resume_skills(resume_data) if resume_data else []
    
    # Calculate skills match
    skills_match = calculate_skills_match(resume_skills, jd_skills)
    
    # Calculate experience match
    experience_match = calculate_experience_match(resume_data, jd_text) if resume_data else None
    
    # Calculate education match
    education_match = calculate_education_match(resume_data, jd_text) if resume_data else None
    
    # Calculate weighted overall score
    overall_score = calculate_weighted_score(
        semantic_score, 
        skills_match, 
        experience_match, 
        education_match
    )
    
    # Generate suggestions
    suggestions = generate_suggestions(resume_data, jd_text, jd_skills, resume_skills) if resume_data else []
    
    # Generate score explanation
    score_explanation = generate_score_explanation(
        semantic_score, 
        skills_match, 
        experience_match, 
        education_match,
        overall_score
    )
    
    return {
        "overall_score": overall_score,
        "semantic_score": semantic_score,
        "skills_match": skills_match,
        "experience_match": experience_match,
        "education_match": education_match,
        "feedback": generate_feedback(overall_score),
        "jd_skills": jd_skills,
        "resume_skills": resume_skills,
        "missing_skills": list(set(jd_skills) - set(resume_skills)),
        "suggestions": suggestions,
        "score_explanation": score_explanation
    }

def calculate_weighted_score(semantic_score, skills_match, experience_match, education_match):
    """Calculate weighted overall score from individual components"""
    weights = {
        'semantic': 0.4,
        'skills': 0.3,
        'experience': 0.2,
        'education': 0.1
    }
    
    # Normalize scores to 0-1 range
    normalized_scores = {
        'semantic': semantic_score / 100,
        'skills': skills_match / 100 if skills_match is not None else 0,
        'experience': experience_match / 100 if experience_match is not None else 0,
        'education': education_match / 100 if education_match is not None else 0
    }
    
    # Calculate weighted sum
    weighted_sum = sum(
        normalized_scores[component] * weights[component] 
        for component in weights.keys()
    )
    
    return round(weighted_sum * 100, 2)

def generate_score_explanation(semantic_score, skills_match, experience_match, education_match, overall_score):
    """Generate explanation for the score breakdown"""
    explanation = []
    
    # Semantic score explanation
    if semantic_score > 80:
        explanation.append("✓ Strong semantic alignment between your resume and the job description")
    elif semantic_score > 60:
        explanation.append("⚠ Good semantic match, but could be improved with better keyword alignment")
    else:
        explanation.append("✗ Low semantic match - consider restructuring your resume to better match the job description")
    
    # Skills match explanation
    if skills_match == 100:
        explanation.append("✓ All required skills are present in your resume")
    elif skills_match > 70:
        explanation.append(f"⚠ Good skills match ({skills_match}%), but some key skills are missing")
    else:
        explanation.append(f"✗ Low skills match ({skills_match}%) - consider adding missing skills")
    
    # Experience match explanation
    if experience_match is not None:
        if experience_match >= 100:
            explanation.append("✓ Your experience meets or exceeds the job requirements")
        elif experience_match > 80:
            explanation.append(f"⚠ Close to required experience level ({experience_match}%)")
        else:
            explanation.append(f"✗ Experience level below requirements ({experience_match}%)")
    
    # Education match explanation
    if education_match is not None:
        if education_match == 100:
            explanation.append("✓ Your education matches the job requirements")
        else:
            explanation.append(f"⚠ Education requirements not fully met ({education_match}%)")
    
    # Overall score explanation
    if overall_score > 80:
        explanation.append(f"🎯 Excellent overall match ({overall_score}%)")
    elif overall_score > 60:
        explanation.append(f"👍 Good overall match ({overall_score}%) with room for improvement")
    else:
        explanation.append(f"🔍 Moderate overall match ({overall_score}%) - consider tailoring your resume")
    
    return explanation

def calculate_education_match(resume_data, jd_text):
    """Calculate education match percentage"""
    if not resume_data or "education" not in resume_data:
        return 0
    
    # Extract education requirements from JD
    education_requirements = []
    if "bachelor" in jd_text.lower():
        education_requirements.append("bachelor")
    if "master" in jd_text.lower():
        education_requirements.append("master")
    if "phd" in jd_text.lower():
        education_requirements.append("phd")
    if "degree" in jd_text.lower():
        education_requirements.append("degree")
    
    if not education_requirements:
        return 100  # No specific education requirements
    
    # Check resume education
    resume_education = " ".join(resume_data["education"]).lower()
    
    # Count how many requirements are met
    met_requirements = 0
    for req in education_requirements:
        if req in resume_education:
            met_requirements += 1
    
    return round((met_requirements / len(education_requirements)) * 100, 2)

def preprocess_text(text):
    """Clean and normalize text for better matching"""
    # Remove extra whitespace, special characters, and normalize
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'[^\w\s]', '', text)
    return text.lower()

def extract_jd_skills(jd_text, skills_db):
    """Extract skills from job description using the skills database"""
    if nlp is None:
        # Fallback: simple keyword matching
        text_lower = jd_text.lower()
        extracted_skills = []
        for category, skills in skills_db.items():
            for skill in skills:
                if skill.lower() in text_lower:
                    extracted_skills.append(skill)
        return list(set(extracted_skills))
    
    doc = nlp(jd_text)
    extracted_skills = set()
    
    # Use PhraseMatcher to find skills in JD
    for category, skills in skills_db.items():
        for skill in skills:
            if skill.lower() in jd_text.lower():
                extracted_skills.add(skill)
    
    # Also extract noun phrases that might be skills
    for chunk in doc.noun_chunks:
        chunk_text = chunk.text.strip()
        if len(chunk_text) > 2 and chunk_text.istitle():
            # Check if this noun phrase is in our skills database
            for category, skills in skills_db.items():
                if chunk_text in skills:
                    extracted_skills.add(chunk_text)
    
    return list(extracted_skills)

def extract_resume_skills(resume_data):
    """Extract skills from parsed resume data"""
    if not resume_data or "skills" not in resume_data:
        return []
    
    all_skills = []
    for category in resume_data["skills"].values():
        all_skills.extend(category)
    
    return list(set(all_skills))

def calculate_skills_match(resume_skills, jd_skills):
    """Calculate skills match percentage"""
    if not jd_skills:
        return 100  # No specific skills required
    
    common_skills = set(resume_skills) & set(jd_skills)
    return round((len(common_skills) / len(jd_skills)) * 100, 2)

def extract_experience_from_jd(jd_text):
    """Extract required experience from JD"""
    # Look for patterns like "5+ years", "5 years", etc.
    patterns = [
        r'(\d+)\s*\+?\s*years?',
        r'at\s*least\s*(\d+)\s*years?',
        r'minimum\s*of\s*(\d+)\s*years?',
        r'(\d+)\s*years?\s*of\s*experience'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, jd_text.lower())
        if match:
            return int(match.group(1))
    
    return None

def calculate_experience_match(resume_data, jd_text):
    """Calculate experience match percentage"""
    if not resume_data or "total_experience" not in resume_data:
        return 0
    
    jd_experience = extract_experience_from_jd(jd_text)
    if not jd_experience:
        return 100  # No specific experience requirement
    
    resume_experience = resume_data["total_experience"]
    if not resume_experience:
        return 0
    
    # Calculate match percentage (capped at 100%)
    match_percentage = min(100, round((resume_experience / jd_experience) * 100, 2))
    return match_percentage

def generate_suggestions(resume_data, jd_text, jd_skills, resume_skills):
    """Generate suggestions to improve resume based on JD"""
    suggestions = []
    
    # Skills suggestions
    missing_skills = list(set(jd_skills) - set(resume_skills))
    if missing_skills:
        suggestions.append({
            "type": "Skills",
            "message": f"Consider adding these skills to your resume: {', '.join(missing_skills[:5])}",
            "priority": "high" if len(missing_skills) > 3 else "medium"
        })
    
    # Experience suggestions
    jd_experience = extract_experience_from_jd(jd_text)
    if jd_experience and resume_data.get("total_experience"):
        resume_experience = resume_data["total_experience"]
        if resume_experience < jd_experience:
            suggestions.append({
                "type": "Experience",
                "message": f"The job requires {jd_experience} years of experience, but your resume shows {resume_experience} years. Highlight relevant projects or roles that demonstrate equivalent experience.",
                "priority": "high"
            })
    
    # Education suggestions
    education_keywords = ["bachelor", "master", "phd", "degree", "certification"]
    jd_education = [kw for kw in education_keywords if kw in jd_text.lower()]
    if jd_education and not resume_data.get("education"):
        suggestions.append({
            "type": "Education",
            "message": f"The job mentions {', '.join(jd_education)} requirements, but your resume doesn't show education details. Consider adding your education background.",
            "priority": "medium"
        })
    
    # Keywords suggestions
    important_keywords = ["developed", "managed", "led", "achieved", "implemented", "created"]
    resume_text = " ".join([str(value) for value in resume_data.values() if isinstance(value, list)])
    missing_keywords = [kw for kw in important_keywords if kw not in resume_text.lower()]
    if missing_keywords:
        suggestions.append({
            "type": "Keywords",
            "message": f"Consider adding action verbs like: {', '.join(missing_keywords)} to make your resume more impactful.",
            "priority": "low"
        })
    
    # Certification suggestions
    cert_keywords = ["certification", "certificate", "licensed", "certified"]
    jd_certifications = [kw for kw in cert_keywords if kw in jd_text.lower()]
    if jd_certifications and not resume_data.get("certifications"):
        suggestions.append({
            "type": "Certifications",
            "message": f"The job mentions {', '.join(jd_certifications)} requirements. Consider adding any relevant certifications you have.",
            "priority": "medium"
        })
    
    # Project suggestions
    if "projects" in jd_text.lower() and "projects" not in resume_data:
        suggestions.append({
            "type": "Projects",
            "message": "The job mentions project experience. Consider adding a projects section to your resume highlighting relevant work.",
            "priority": "medium"
        })
    
    return suggestions

def generate_feedback(score):
    """Generate professional feedback based on score"""
    if score > 90:
        return "✅ Exceptional match! Your resume strongly aligns with this position."
    elif score > 75:
        return "👍 Strong match. Highlight your relevant experience in the application."
    elif score > 60:
        return "⚠️ Moderate match. Emphasize transferable skills in your cover letter."
    elif score > 45:
        return "🔍 Potential match with some gaps. Consider tailoring your resume."
    else:
        return "❌ Weak match. Significant differences between your resume and this position."

# Example usage
if __name__ == "__main__":
    # Test with sample data
    sample_jd = """
    We are looking for a Senior Python Developer with 5+ years of experience in web development.
    The ideal candidate should have strong skills in Python, Django, React, and AWS.
    Experience with machine learning and data analysis is a plus.
    Bachelor's degree in Computer Science or related field is required.
    """
    
    sample_resume = {
        "skills": {
            "technical": ["Python", "Django", "JavaScript", "SQL"],
            "soft": ["Communication", "Teamwork"]
        },
        "total_experience": 4.5,
        "education": ["Bachelor in Computer Science"],
        "certifications": ["AWS Certified Developer"]
    }
    
    result = compute_match_score("Sample resume text", sample_jd, sample_resume)
    print("Match Results:")
    print(json.dumps(result, indent=2))